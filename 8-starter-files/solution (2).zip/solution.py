from typing import Generator, Tuple


# Given a graph (undirected), determine whether or not it is a tree.
# The input will be fairly abstract as to leave the graph implementation up to the student.
# The input will have the number of nodes and then a generator* of edges.
# Nodes are numbered 0 to n-1 (inclusive).

# *you can iterate over the elements of a generator (as shown in the starter code)

# It is guaranteed that the number of vertices N <= 1e6 aka 1 million.
# The edge generator will not contain any duplicates.

# Recall that a tree is a connected acyclic graph.
# There are many equivalent definitions that will lead to different implementations.

def is_tree(n: int, edges: Generator[Tuple[int, int], None, None]) -> bool:
   
    array = [[] for _ in range(n)]
    tru = [0] * n
    ret = True

    
    for u, v in edges:
       
        if (len(array[u]) == 0 and len(array[v]) == 0 and u != v):
            array[v].append(u)
            array[u].append(v)

        else:
            if v in array[u] and u in array[v]:
                ret = False 
            elif  u != v :
                array[u].append(v)
                array[v].append(u) 
                
        
                 
                  
    for index , x in enumerate(array): 
        cnt = 0
        for y in x:
            if tru[index] == 0:
                tru[index] = 1
            if tru[y] == 1:
                cnt += 1
        if (cnt > 1):
            ret = False
    if n > 1:
        for i in tru: 
            if i == 0:
                ret = False
    elif n == 1:
        ret = True

    return ret 

